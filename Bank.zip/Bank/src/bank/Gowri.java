/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class Gowri {
    public static Connection ConnectDB(){
          try{
              Class.forName("oracle.jdbc.OracleDriver");
              Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","gowri","gowri");
             // JOptionPane.showMessageDialog(null,"Connection Established!");
              return con;
          }
          catch(Exception e){
              JOptionPane.showMessageDialog(null,e);
          }
          return null;
              }      

    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
